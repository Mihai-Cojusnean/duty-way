create function trunc(numeric) returns numeric
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
select pg_catalog.trunc($1,0)
$$;

comment on function trunc(numeric) is 'value truncated to ''scale'' of zero';

alter function trunc(numeric) owner to postgres;

